using UnityEngine;

public class EnemigoVida : VidaBase
{
    [SerializeField] private PersonajeStats stats;  // Assign enemy-specific stats here

    private bool derrotado = false;

    private void Awake()
    {
        // Initialize enemy health from its own stats, not player stats
        saludInicial = CalculateHealth(stats);
        saludMax = saludInicial;
        Salud = saludInicial;
    }

    protected override void Start()
    {
        base.Start();
        ActualizarBarraVida(Salud, saludMax);
    }

    private float CalculateHealth(PersonajeStats stats)
    {
        // Example formula: base 50 + defense * 10, change as needed
        return 50f + stats.Defensa * 10f;
    }

    protected override void ActualizarBarraVida(float vidaActual, float vidaMax)
    {
        // Optional: Update enemy health bar UI here
    }

    protected override void PersonajeDerrotado()
    {
        if (derrotado) return;
        derrotado = true;
        Debug.Log($"{gameObject.name} ha sido derrotado.");
        Destroy(gameObject, 1f);  // Destroy enemy after 1 second
    }
}