using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class QuestManager : Singleton<QuestManager>
{
    [Header("Personaje")]
    [SerializeField] private Personaje personaje;

    [Header("Quests")]
    [SerializeField] private Quest[] questDisponibles;

    [Header("Inspector Quests")]
    [SerializeField] private InspectorQuestDescripcion inspectorQuestPrefab;
    [SerializeField] private Transform inspectorQuestContenedor;

    [Header("Personaje Quests")]
    [SerializeField] private PersonajeQuestDescripcion personajeQuestPrefab;
    [SerializeField] private Transform personajeQuestContenedor;

    [Header("Panel Quest Completado")]
    [SerializeField] private GameObject panelQuestCompletado;
    [SerializeField] private TextMeshProUGUI questNombre;
    [SerializeField] private TextMeshProUGUI questRecompensaOro;
    [SerializeField] private TextMeshProUGUI questRecompensaExp;
    [SerializeField] private TextMeshProUGUI questRecompensaItemCantidad;
    [SerializeField] private Image questRecompensaItemIcono;

    private List<Quest> activeQuests = new List<Quest>();

    public Quest QuestPorReclamar { get; private set; }

    private void Start()
    {
        CargarQuestEnInspector();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.V))
        {
            AñadirProgreso("Mata2", 1);
            AñadirProgreso("Mata25", 1);
            AñadirProgreso("Mata50", 1);
        }
    }

    private void CargarQuestEnInspector()
    {
        for (int i = 0; i < questDisponibles.Length; i++)
        {
            InspectorQuestDescripcion nuevoQuest = Instantiate(inspectorQuestPrefab, inspectorQuestContenedor);
            nuevoQuest.ConfigurarQuestUI(questDisponibles[i]);
        }
    }

    private void AñadirQuestPorCompletar(Quest questPorCompletar)
    {
        PersonajeQuestDescripcion nuevoQuest = Instantiate(personajeQuestPrefab, personajeQuestContenedor);
        nuevoQuest.ConfigurarQuestUI(questPorCompletar);
    }

    // Add a quest to the player's active quests if not already added
    public void AñadirQuest(Quest questPorCompletar)
    {
        if (!activeQuests.Contains(questPorCompletar))
        {
            activeQuests.Add(questPorCompletar);
            AñadirQuestPorCompletar(questPorCompletar);
        }
    }

    public void ReclamarRecompensa()
    {
        if (QuestPorReclamar == null)
            return;

        MonedasManager.Instance.AñadirMonedas(QuestPorReclamar.RecompensaOro);
        personaje.PersonajeExperiencia.AñadirExperiencia(QuestPorReclamar.RecompensaExp);
        Inventario.Instance.AñadirItem(QuestPorReclamar.RecompensaItem.Item, QuestPorReclamar.RecompensaItem.Cantidad);
        panelQuestCompletado.SetActive(false);
        QuestPorReclamar = null;
    }

    public void AñadirProgreso(string questID, int cantidad)
    {
        Quest questPorActualizar = activeQuests.Find(q => q.ID == questID);

        if (questPorActualizar == null)
        {
            Debug.LogWarning($"[QuestManager] Tried to add progress to quest '{questID}', but it is not active.");
            PrintActiveQuests();
            return;
        }

        questPorActualizar.AñadirProgreso(cantidad);
    }

    private void MostrarQuestCompletado(Quest questCompletado)
    {
        panelQuestCompletado.SetActive(true);
        questNombre.text = questCompletado.Nombre;
        questRecompensaOro.text = questCompletado.RecompensaOro.ToString();
        questRecompensaExp.text = questCompletado.RecompensaExp.ToString();
        questRecompensaItemCantidad.text = questCompletado.RecompensaItem.Cantidad.ToString();
        questRecompensaItemIcono.sprite = questCompletado.RecompensaItem.Item.Icono;
    }

    private void QuestCompletadoRespuesta(Quest questCompletado)
    {
        QuestPorReclamar = activeQuests.Find(q => q.ID == questCompletado.ID);
        if (QuestPorReclamar != null)
        {
            MostrarQuestCompletado(QuestPorReclamar);
        }
    }

    private void OnEnable()
    {
        Quest.EventoQuestCompletado += QuestCompletadoRespuesta;
        EnemyDeathTracker.OnEnemyDeath += OnEnemyDeath;
    }

    private void OnDisable()
    {
        Quest.EventoQuestCompletado -= QuestCompletadoRespuesta;
        EnemyDeathTracker.OnEnemyDeath -= OnEnemyDeath;
    }

    private void OnEnemyDeath()
    {
        // Only update active kill quests when an enemy dies
        foreach (Quest quest in activeQuests)
        {
            if (!quest.QuestCompletadoCheck && quest.ID.StartsWith("Mata"))
            {
                quest.AñadirProgreso(1);
            }
        }
    }

    private void PrintActiveQuests()
    {
        Debug.Log("[QuestManager] Active quests:");
        foreach (var quest in activeQuests)
        {
            Debug.Log($"→ {quest.ID}");
        }
    }
}
