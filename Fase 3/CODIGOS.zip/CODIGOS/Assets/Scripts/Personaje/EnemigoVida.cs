﻿using UnityEngine;
using System.Collections;

public class CharacterHealth : MonoBehaviour
{
    [SerializeField] private float maxHealth = 100f;
    [SerializeField] private float respawnDelay = 5f;

    private float currentHealth;
    private float totalDamageTaken;

    private Vector3 initialPosition;
    private Quaternion initialRotation;

    private Collider2D enemyCollider;
    private Renderer enemyRenderer;
    private MonoBehaviour[] enemyBehaviors;

    public bool IsDead { get; private set; } = false;

    private void Awake()
    {
        currentHealth = maxHealth;
        totalDamageTaken = 0f;

        initialPosition = transform.position;
        initialRotation = transform.rotation;

        enemyCollider = GetComponent<Collider2D>();
        enemyRenderer = GetComponent<Renderer>();

        // Cache all MonoBehaviours on this GameObject (includes scripts like AI, movement, etc.)
        enemyBehaviors = GetComponents<MonoBehaviour>();
    }

    public void TakeDamage(float amount)
    {
        if (IsDead) return;

        currentHealth -= amount;
        totalDamageTaken += amount;

        Debug.Log($"{gameObject.name} took {amount} damage (Total damage taken: {totalDamageTaken})");

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    public float GetTotalDamageTaken() => totalDamageTaken;

    private void Die()
    {
        Debug.Log($"{gameObject.name} died.");
        IsDead = true;

        // Report to quest system BEFORE disabling any components
        EnemyDeathTracker.ReportEnemyDeath();

        // Disable collider and renderer
        if (enemyCollider != null) enemyCollider.enabled = false;
        if (enemyRenderer != null) enemyRenderer.enabled = false;

        // Disable all other scripts except this one
        foreach (var script in enemyBehaviors)
        {
            if (script != this)
                script.enabled = false;
        }

        // Start respawn coroutine
        StartCoroutine(RespawnCoroutine());
    }

    private IEnumerator RespawnCoroutine()
    {
        yield return new WaitForSeconds(respawnDelay);

        // Reset position and rotation
        transform.position = initialPosition;
        transform.rotation = initialRotation;

        // Reset health values
        currentHealth = maxHealth;
        totalDamageTaken = 0f;
        IsDead = false;

        // Re-enable collider and renderer
        if (enemyCollider != null) enemyCollider.enabled = true;
        if (enemyRenderer != null) enemyRenderer.enabled = true;

        // Re-enable all scripts (except this one which is already active)
        foreach (var script in enemyBehaviors)
        {
            if (script != this)
                script.enabled = true;
        }

        Debug.Log($"{gameObject.name} has respawned.");
    }
}
