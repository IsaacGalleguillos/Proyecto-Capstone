using UnityEngine;

[CreateAssetMenu(menuName = "Stats")]
public class PersonajeStats : ScriptableObject
{
    [Header("Stats")]
    public float Daño = 5f;
    public float Defensa = 2f;
    public float Velocidad = 5f;
    public float Nivel = 1;
    public float ExpActual = 0f;
    public float ExpRequeridaSiguienteNivel = 100f;
    [Range(0f, 100f)] public float PorcentajeCritico = 0f;
    [Range(0f, 100f)] public float PorcentajeBloqueo = 0f;

    [Header("Atributos")]
    public int Fuerza = 0;
    public int Inteligencia = 0;
    public int Destreza = 0;

    [HideInInspector]
    public int PuntosDisponibles = 0;

    public void AñadirBonudPorAtributoFuerza()
    {
        Defensa += 1f;
        PorcentajeBloqueo += 0.03f;
    }

    public void AñadirBonusPorAtributoInteligencia()
    {
        Daño += 1f;
        PorcentajeCritico += 0.2f;
    }

    public void AñadirBonusPorAtributoDestreza()
    {
        Velocidad += 0.1f;
        PorcentajeBloqueo += 0.05f;
    }

    public void AñadirBonusPorArma(Arma arma)
    {
        Daño += arma.Daño;
        PorcentajeCritico += arma.ChanceCritico;
        PorcentajeBloqueo += arma.ChanceBloqueo;
    }

    public void RemoverBonusPorArma(Arma arma)
    {
        Daño -= arma.Daño;
        PorcentajeCritico -= arma.ChanceCritico;
        PorcentajeBloqueo -= arma.ChanceBloqueo;
    }

    public void ResetearValores()
    {
        Daño = 5f;
        Defensa = 2f;
        Velocidad = 5f;
        Nivel = 1;
        ExpActual = 0f;
        ExpRequeridaSiguienteNivel = 100f;
        PorcentajeBloqueo = 0f;
        PorcentajeCritico = 0f;

        Fuerza = 0;
        Inteligencia = 0;
        Destreza = 0;
        PuntosDisponibles = 0;
    }
}
