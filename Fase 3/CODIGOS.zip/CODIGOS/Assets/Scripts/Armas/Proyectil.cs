﻿using System.Collections;
using UnityEngine;

public class Proyectil : MonoBehaviour
{
    public float damage = 10f;
    public float lifeTime = 5f;
    public float speed = 10f;

    private EnemigoInteraccion target;
    private GameObject shooter;
    private Collider2D[] projectileColliders;

    public void InicializarProyectil(EnemigoInteraccion targetEnemigo, GameObject shooterObject, float damageValue = 10f, float lifeTimeValue = 5f)
    {
        target = targetEnemigo;
        shooter = shooterObject;
        damage = damageValue;
        lifeTime = lifeTimeValue;

        projectileColliders = GetComponentsInChildren<Collider2D>();
        Collider2D[] shooterColliders = shooter.GetComponentsInChildren<Collider2D>();

        foreach (var pCol in projectileColliders)
        {
            foreach (var sCol in shooterColliders)
            {
                Physics2D.IgnoreCollision(pCol, sCol, true);
            }
        }

        CancelInvoke(nameof(DestroySelf));
        Invoke(nameof(DestroySelf), lifeTime);
    }

    private void OnEnable()
    {
        CancelInvoke();
        Invoke(nameof(DestroySelf), lifeTime);
    }

    private void OnDisable()
    {
        CancelInvoke();
        target = null;
        shooter = null;
    }

    private void Update()
    {
        if (target != null)
        {
            Vector3 direction = (target.transform.position - transform.position).normalized;
            transform.position += direction * speed * Time.deltaTime;
        }
        else
        {
            // move forward in local up direction if no target
            transform.Translate(Vector3.up * speed * Time.deltaTime);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (shooter != null && (other.gameObject == shooter || other.transform.IsChildOf(shooter.transform)))
            return;

        CharacterHealth health = other.GetComponent<CharacterHealth>() ?? other.GetComponentInParent<CharacterHealth>();

        if (health != null)
        {
            if (health.IsDead)
                return;

            health.TakeDamage(damage);
            Debug.Log($"Projectile hit {other.name} for {damage} damage.");
        }
        else
        {
            Debug.Log($"Projectile hit {other.name}, but no CharacterHealth found.");
        }

        gameObject.SetActive(false);
    }

    private void DestroySelf()
    {
        gameObject.SetActive(false);
    }

#if UNITY_EDITOR
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, 0.2f); // visualize projectile origin
    }
#endif
}
