using System;

public static class EnemyDeathTracker
{
    // Event triggered whenever an enemy dies
    public static event Action OnEnemyDeath;

    public static void ReportEnemyDeath()
    {
        OnEnemyDeath?.Invoke();
    }
}